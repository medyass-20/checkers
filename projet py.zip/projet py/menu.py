import pygame
import pygame.freetype
import random
from checkers.constants import WIDTH, HEIGHT

# Initialisation
pygame.init()
pygame.freetype.init()

# Polices
try:
    title_font = pygame.freetype.Font("assets/fonts/Montserrat-Bold.ttf", 72)
    button_font = pygame.freetype.Font("assets/fonts/Montserrat-Medium.ttf", 42)
    text_font = pygame.freetype.Font("assets/fonts/Montserrat-Regular.ttf", 32)
except:
    title_font = pygame.freetype.SysFont("Arial", 72, bold=True)
    button_font = pygame.freetype.SysFont("Arial", 42)
    text_font = pygame.freetype.SysFont("Arial", 32)

# Couleurs
COLORS = {
    "background": (28, 35, 43),
    "primary": (41, 128, 185),
    "secondary": (39, 174, 96),
    "accent": (231, 76, 60),
    "text": (236, 240, 241),
    "text_dark": (44, 62, 80),
    "overlay": (0, 0, 0, 180)
}

class Button:
    def __init__(self, x, y, width, height, text, color, hover_color):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.current_color = color
        self.is_hovered = False

    def draw(self, surface):
        color = self.hover_color if self.is_hovered else self.color
        pygame.draw.rect(surface, color, self.rect, border_radius=10)
        pygame.draw.rect(surface, COLORS["text_dark"], self.rect, 2, border_radius=10)
        text_surf, text_rect = button_font.render(self.text, COLORS["text_dark"])
        text_rect.center = self.rect.center
        surface.blit(text_surf, text_rect)

    def update_hover(self, mouse_pos):
        self.is_hovered = self.rect.collidepoint(mouse_pos)

    def is_clicked(self, mouse_pos, mouse_click):
        return self.rect.collidepoint(mouse_pos) and mouse_click

class GameModeMenu:
    def __init__(self, win):
        self.win = win
        self.buttons = [
            Button(WIDTH//2 - 150, 250, 300, 70, "MULTIPLAYER", COLORS["primary"], (52, 152, 219)),
            Button(WIDTH//2 - 150, 350, 300, 70, "VS AI", COLORS["secondary"], (46, 204, 113)),
            Button(WIDTH//2 - 150, 450, 300, 70, "BACK", COLORS["accent"], (192, 57, 43))
        ]

    def draw(self, surface):
        surface.fill(COLORS["background"])
        title_surf, title_rect = title_font.render("SELECT MODE", COLORS["text"])
        title_rect.midtop = (WIDTH//2, 100)
        surface.blit(title_surf, title_rect)
        for button in self.buttons:
            button.draw(surface)

    def run(self):
        clock = pygame.time.Clock()
        while True:
            mouse_pos = pygame.mouse.get_pos()
            mouse_click = False
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return "quit"
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_click = True
            
            for button in self.buttons:
                button.update_hover(mouse_pos)
                if button.is_clicked(mouse_pos, mouse_click):
                    if button.text == "MULTIPLAYER":
                        return "multiplayer"
                    elif button.text == "VS AI":
                        return "vsAI"
                    elif button.text == "BACK":
                        return "back"
            
            self.draw(self.win)
            pygame.display.flip()
            clock.tick(60)

class PauseMenu:
    def __init__(self, win):
        self.win = win
        self.buttons = [
            Button(WIDTH//2 - 150, 250, 300, 70, "RESUME", COLORS["secondary"], (46, 204, 113)),
            Button(WIDTH//2 - 150, 350, 300, 70, "MAIN MENU", COLORS["primary"], (52, 152, 219)),
            Button(WIDTH//2 - 150, 450, 300, 70, "QUIT", COLORS["accent"], (192, 57, 43))
        ]

    def draw(self, surface):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill(COLORS["overlay"])
        surface.blit(overlay, (0, 0))
        
        box = pygame.Rect(WIDTH//2 - 200, HEIGHT//2 - 200, 400, 400)
        pygame.draw.rect(surface, COLORS["background"], box, border_radius=20)
        
        title_surf, title_rect = title_font.render("PAUSED", COLORS["text"])
        title_rect.midtop = (WIDTH//2, HEIGHT//2 - 150)
        surface.blit(title_surf, title_rect)
        
        for button in self.buttons:
            button.draw(surface)

    def run(self):
        clock = pygame.time.Clock()
        while True:
            mouse_pos = pygame.mouse.get_pos()
            mouse_click = False
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return "quit"
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    return "resume"
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_click = True
            
            for button in self.buttons:
                button.update_hover(mouse_pos)
                if button.is_clicked(mouse_pos, mouse_click):
                    if button.text == "RESUME":
                        return "resume"
                    elif button.text == "MAIN MENU":
                        return "main_menu"
                    elif button.text == "QUIT":
                        return "quit"
            
            self.draw(self.win)
            pygame.display.flip()
            clock.tick(60)

class MainMenu:
    def __init__(self, win):
        self.win = win
        self.buttons = [
            Button(WIDTH//2 - 150, 250, 300, 70, "PLAY", COLORS["secondary"], (46, 204, 113)),
            Button(WIDTH//2 - 150, 350, 300, 70, "ABOUT", COLORS["primary"], (52, 152, 219)),
            Button(WIDTH//2 - 150, 450, 300, 70, "QUIT", COLORS["accent"], (192, 57, 43))
        ]
        self.game_mode_menu = GameModeMenu(win)
        self.show_about = False
        self.about_text = [
            "Developed by:",
            "Mohammed Yassine Habchi",
            "Mohamed Walid Kharmoudi",
            "Amine Izmaoun",
            "Anass Chadli",
            "Mohamed Zaari",
            "Youssef Boulafra",
            "Mohamed Aymane Bouhmouch"
        ]

    def draw_about(self, surface):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill(COLORS["overlay"])
        surface.blit(overlay, (0, 0))
        
        # Ajustement de la taille de la boîte About
        box_height = 500  # Augmenté pour accommoder tout le texte
        box = pygame.Rect(WIDTH//2 - 250, HEIGHT//2 - box_height//2, 500, box_height)
        pygame.draw.rect(surface, COLORS["background"], box, border_radius=20)
        
        # Titre
        title_surf, title_rect = title_font.render("ABOUT", COLORS["text"])
        title_rect.midtop = (WIDTH//2, HEIGHT//2 - box_height//2 + 30)
        surface.blit(title_surf, title_rect)
        
        # Texte développeurs avec espacement ajusté
        start_y = HEIGHT//2 - box_height//2 + 120
        line_height = 40
        
        for i, line in enumerate(self.about_text):
            if line:  # Ne pas dessiner les lignes vides
                text_surf, text_rect = text_font.render(line, COLORS["text"])
                text_rect.midtop = (WIDTH//2, start_y + i * line_height)
                surface.blit(text_surf, text_rect)
        
        # Bouton Back positionné en bas de la boîte
        back_button = Button(WIDTH//2 - 75, HEIGHT//2 + box_height//4 + 80, 150, 50, "BACK", COLORS["accent"], (192, 57, 43))
        back_button.draw(surface)
        return back_button

    def draw(self, surface):
        surface.fill(COLORS["background"])
        
        if self.show_about:
            back_button = self.draw_about(surface)
            return back_button
        else:
            title_surf, title_rect = title_font.render("CHECKERS", COLORS["text"])
            title_rect.midtop = (WIDTH//2, 100)
            surface.blit(title_surf, title_rect)
            
            for button in self.buttons:
                button.draw(surface)
            return None

    def run(self):
        clock = pygame.time.Clock()
        while True:
            mouse_pos = pygame.mouse.get_pos()
            mouse_click = False
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return "quit"
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_click = True
            
            if self.show_about:
                back_button = self.draw(self.win)
                back_button.update_hover(mouse_pos)
                if back_button.is_clicked(mouse_pos, mouse_click):
                    self.show_about = False
            else:
                for button in self.buttons:
                    button.update_hover(mouse_pos)
                    if button.is_clicked(mouse_pos, mouse_click):
                        if button.text == "PLAY":
                            mode = self.game_mode_menu.run()
                            if mode in ["multiplayer", "vsAI"]:
                                return mode
                        elif button.text == "ABOUT":
                            self.show_about = True
                        elif button.text == "QUIT":
                            pygame.quit()
                            return "quit"
            
            self.draw(self.win)
            pygame.display.flip()
            clock.tick(60)