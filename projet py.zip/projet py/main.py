import pygame
from checkers.constants import WIDTH, HEIGHT, SQUARE_SIZE, PIECE_LIGHT, PIECE_DARK
from checkers.game import Game
from menu import MainMenu, PauseMenu
from checkers.AIplayer import AIPlayer

FPS = 60
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Checkers')

def get_row_col_from_mouse(pos):
    x, y = pos
    row = y // SQUARE_SIZE
    col = x // SQUARE_SIZE
    return row, col

def main():
    pygame.init()
    run = True
    clock = pygame.time.Clock()
    
    # Menu principal
    main_menu = MainMenu(WIN)
    game_mode = main_menu.run()
    
    if game_mode == "quit":
        pygame.quit()
        return
    
    # Initialiser le jeu
    game = Game(WIN)
    ai_player = None
    
    # Configurer l'IA si nécessaire
    if game_mode == "vsAI":
        ai_player = AIPlayer(PIECE_LIGHT)  # L'IA joue les rouges
    
    # Variables pour gérer le tour de l'IA
    ai_thinking = False
    ai_move_time = 0
    
    while run:
        clock.tick(FPS)
        
        # Gestion du tour de l'IA
        if game_mode == "vsAI" and game.turn == PIECE_LIGHT and not ai_thinking:
            ai_thinking = True
            ai_move_time = pygame.time.get_ticks()
        
        if ai_thinking and pygame.time.get_ticks() - ai_move_time > 300:
            ai_player.make_move(game)
            ai_thinking = False

        # Vérifier le gagnant
        winner = game.winner()
        if winner is not None:
            print(f"Le gagnant est : {winner}")
            pygame.time.delay(2000)
            main_menu = MainMenu(WIN)
            game_mode = main_menu.run()
            if game_mode == "quit":
                run = False
            else:
                game = Game(WIN)
                ai_player = AIPlayer(PIECE_LIGHT) if game_mode == "vsAI" else None
            continue

        # Gestion des événements
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pause_menu = PauseMenu(WIN)
                    pause_result = pause_menu.run()
                    if pause_result == "quit":
                        run = False
                    elif pause_result == "main_menu":
                        main_menu = MainMenu(WIN)
                        game_mode = main_menu.run()
                        if game_mode == "quit":
                            run = False
                        else:
                            game = Game(WIN)
                            ai_player = AIPlayer(PIECE_LIGHT) if game_mode == "vsAI" else None
            
            # Ne traiter les clics que si c'est le tour du joueur humain
            if event.type == pygame.MOUSEBUTTONDOWN and (game_mode == "multiplayer" or game.turn == PIECE_DARK):
                pos = pygame.mouse.get_pos()
                row, col = get_row_col_from_mouse(pos)
                game.select(row, col)

        game.update()
    
    pygame.quit()

if __name__ == "__main__":
    main()