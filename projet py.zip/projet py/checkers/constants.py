import pygame

WIDTH, HEIGHT = 800, 800
ROWS, COLS = 8, 8
SQUARE_SIZE = WIDTH//COLS

# rgb
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)
GREY = (128,128,128)
WHITE = (255, 255, 255)
BOARD_DARK = (115, 149, 82)
BOARD_LIGHT = (235, 236, 208)
PIECE_DARK = (92, 89, 87)
PIECE_LIGHT = (216, 64, 64)

CROWN = pygame.transform.scale(pygame.image.load('assets/crown.png'), (44, 25))
