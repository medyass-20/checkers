import random
from .constants import ROWS, COLS, PIECE_LIGHT, PIECE_DARK

class AIPlayer:
    def __init__(self, color, difficulty=2):
        self.color = color
        self.difficulty = difficulty  # 1: Easy, 2: Medium, 3: Hard
        self.depth = {1: 3, 2: 5, 3: 7}[difficulty]  # Search depth per difficulty

    def evaluate_board(self, board):
        score = 0
        capture_opportunities = 0
        opponent_color = PIECE_LIGHT if self.color == PIECE_DARK else PIECE_DARK

        for row in range(ROWS):
            for col in range(COLS):
                piece = board.get_piece(row, col)
                if piece != 0:
                    # Basic piece count
                    if piece.color == self.color:
                        score += 10  # Value of a regular piece
                        if piece.king:
                            score += 30  # Higher value for kings
                        # Positional bonuses
                        if row in [3, 4] and col in [3, 4]:  # Center control
                            score += 5
                        if col in [0, 7]:  # Edge safety
                            score += 3
                        if (piece.color == PIECE_DARK and row == 0) or (piece.color == PIECE_LIGHT and row == 7):
                            score += 10  # King row bonus
                    else:
                        score -= 10
                        if piece.king:
                            score -= 30
                        if row in [3, 4] and col in [3, 4]:
                            score -= 5
                        if col in [0, 7]:
                            score -= 3
                        if (piece.color == PIECE_DARK and row == 0) or (piece.color == PIECE_LIGHT and row == 7):
                            score -= 10

                # Estimate capture opportunities
                if piece != 0 and piece.color == self.color:
                    moves = board.get_valid_moves(piece)
                    for move, skipped in moves.items():
                        if skipped:
                            capture_opportunities += len(skipped) * 15  # Bonus for possible captures

        # Add capture opportunities and penalize opponent's
        score += capture_opportunities
        return score

    def get_all_moves(self, game):
        valid_moves = []
        for row in range(ROWS):
            for col in range(COLS):
                piece = game.board.get_piece(row, col)
                if piece != 0 and piece.color == self.color:
                    moves = game.board.get_valid_moves(piece)
                    for move, skipped in moves.items():
                        valid_moves.append(((row, col), move, skipped))
        # Prioritize capture moves
        valid_moves.sort(key=lambda x: len(x[2]), reverse=True)
        return valid_moves

    def simulate_move(self, game, piece_pos, move, skipped):
        piece = game.board.get_piece(piece_pos[0], piece_pos[1])
        original_row, original_col = piece.row, piece.col
        was_king = piece.king
        game.board.move(piece, move[0], move[1])
        if skipped:
            game.board.remove(skipped)
        # Handle king promotion
        if move[0] == 0 or move[0] == ROWS - 1:
            piece.make_king()
            if piece.color == PIECE_LIGHT:
                game.board.red_kings += 1
            else:
                game.board.white_kings += 1
        return original_row, original_col, was_king, skipped

    def undo_move(self, game, piece_pos, original_row, original_col, was_king, skipped):
        piece = game.board.get_piece(piece_pos[0], piece_pos[1])
        game.board.move(piece, original_row, original_col)
        if not was_king:
            piece.king = False
            if piece.color == PIECE_LIGHT:
                game.board.red_kings -= 1
            else:
                game.board.white_kings -= 1
        if skipped:
            for skip_piece in skipped:
                game.board.board[skip_piece.row][skip_piece.col] = skip_piece
                if skip_piece.color == PIECE_LIGHT:
                    game.board.red_left += 1
                else:
                    game.board.white_left += 1

    def minimax(self, game, depth, alpha, beta, maximizing):
        if depth == 0 or game.winner() is not None:
            return self.evaluate_board(game.board), None

        valid_moves = self.get_all_moves(game)
        if not valid_moves:
            return self.evaluate_board(game.board), None

        if maximizing:
            max_eval = float('-inf')
            best_move = None
            for piece_pos, move, skipped in valid_moves:
                original_row, original_col, was_king, skipped = self.simulate_move(game, piece_pos, move, skipped)
                eval_score, _ = self.minimax(game, depth - 1, alpha, beta, False)
                self.undo_move(game, move, original_row, original_col, was_king, skipped)
                if eval_score > max_eval:
                    max_eval = eval_score
                    best_move = (piece_pos, move)
                alpha = max(alpha, max_eval)
                if beta <= alpha:
                    break
            return max_eval, best_move
        else:
            min_eval = float('inf')
            best_move = None
            opponent = AIPlayer(PIECE_LIGHT if self.color == PIECE_DARK else PIECE_DARK, self.difficulty)
            for piece_pos, move, skipped in opponent.get_all_moves(game):
                original_row, original_col, was_king, skipped = self.simulate_move(game, piece_pos, move, skipped)
                eval_score, _ = self.minimax(game, depth - 1, alpha, beta, True)
                self.undo_move(game, move, original_row, original_col, was_king, skipped)
                if eval_score < min_eval:
                    min_eval = eval_score
                    best_move = (piece_pos, move)
                beta = min(beta, min_eval)
                if beta <= alpha:
                    break
            return min_eval, best_move

    def make_move(self, game):
        valid_moves = self.get_all_moves(game)
        if not valid_moves:
            return False

        # Use minimax to select the best move
        _, best_move = self.minimax(game, self.depth, float('-inf'), float('inf'), True)
        if best_move is None:
            # Fallback to random move if no move is found (should be rare)
            piece_pos, move, _ = random.choice(valid_moves)
        else:
            piece_pos, move = best_move

        # Execute the selected move
        game.select(piece_pos[0], piece_pos[1])
        game.select(move[0], move[1])
        return True