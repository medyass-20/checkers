import random
from .constants import ROWS, COLS, PIECE_LIGHT, PIECE_DARK

class AIPlayer:
    def __init__(self, color, difficulty=2):
        self.color = color
        self.difficulty = difficulty  # 1: Facile, 2: Moyen, 3: Difficile

    def evaluate_board(self, board):
        score = 0
        for row in range(ROWS):
            for col in range(COLS):
                piece = board.get_piece(row, col)
                if piece != 0:
                    if piece.color == self.color:
                        score += 1
                        if piece.king:
                            score += 3
                    else:
                        score -= 1
                        if piece.king:
                            score -= 3
        return score

    def make_move(self, game):
        valid_moves = {}
        for row in range(ROWS):
            for col in range(COLS):
                piece = game.board.get_piece(row, col)
                if piece != 0 and piece.color == self.color:
                    moves = game.board.get_valid_moves(piece)
                    if moves:
                        valid_moves[(row, col)] = moves

        if not valid_moves:
            return False

        if self.difficulty == 2:
            # Mode facile: mouvement aléatoire
            piece_pos = random.choice(list(valid_moves.keys()))
            moves = valid_moves[piece_pos]
            move = random.choice(list(moves.keys()))
        else:
            # Mode moyen/difficile: meilleur mouvement
            best_score = float('-inf')
            best_move = None
            best_piece_pos = None
            
            for piece_pos in valid_moves:
                for move, skip in valid_moves[piece_pos].items():
                    # Simule le mouvement
                    piece = game.board.get_piece(piece_pos[0], piece_pos[1])
                    original_row, original_col = piece.row, piece.col
                    game.board.move(piece, move[0], move[1])
                    if skip:
                        game.board.remove(skip)
                    
                    # Évalue le plateau
                    score = self.evaluate_board(game.board)
                    
                    # Annule le mouvement
                    game.board.move(piece, original_row, original_col)
                    
                    if score > best_score:
                        best_score = score
                        best_move = move
                        best_piece_pos = piece_pos

            if best_move is None:
                return False
                
            piece_pos = best_piece_pos
            move = best_move

        # Effectue le mouvement sélectionné
        game.select(piece_pos[0], piece_pos[1])
        game.select(move[0], move[1])
        return True