import pygame
from .constants import PIECE_DARK, PIECE_LIGHT, BLUE, SQUARE_SIZE, ROWS, COLS
from .board import Board

class Game:
    def __init__(self, win):
        self._init()
        self.win = win
    
    def update(self):
        self.board.draw(self.win)
        self.draw_valid_moves(self.valid_moves)
        pygame.display.update()

    def _init(self):
        self.selected = None
        self.board = Board()
        self.turn = PIECE_DARK
        self.valid_moves = {}

    def winner(self):
        return self.board.winner()

    def reset(self):
        self._init()

    def select(self, row, col):
        if self.selected:
            result = self._move(row, col)
            if not result:
                self.selected = None
                self.select(row, col)
        
        piece = self.board.get_piece(row, col)
        if piece != 0 and piece.color == self.turn:
            self.selected = piece
            self.valid_moves = self.board.get_valid_moves(piece)
            return True
            
        return False

    def _move(self, row, col):
        piece = self.board.get_piece(row, col)
        if self.selected and piece == 0 and (row, col) in self.valid_moves:
            self.board.move(self.selected, row, col)
            skipped = self.valid_moves[(row, col)]
            
            if skipped:
                self.board.remove(skipped)
                # Vérifier les sauts multiples
                new_moves = self.board.get_valid_moves(self.selected)
                capture_moves = {move: skips for move, skips in new_moves.items() if skips}
                
                if capture_moves:
                    self.valid_moves = capture_moves
                    return True  # Rester sur la même pièce
            
            # Promotion en king
            if row == 0 or row == ROWS - 1:
                self.selected.make_king()
                if self.selected.color == PIECE_LIGHT:
                    self.board.red_kings += 1
                else:
                    self.board.white_kings += 1
            
            self.change_turn()
            return True
        return False

    def draw_valid_moves(self, moves):
        for move in moves:
            row, col = move
            pygame.draw.circle(self.win, BLUE, (col * SQUARE_SIZE + SQUARE_SIZE//2, row * SQUARE_SIZE + SQUARE_SIZE//2), 15)

    def change_turn(self):
        self.valid_moves = {}
        if self.turn == PIECE_DARK:
            self.turn = PIECE_LIGHT
        else:
            self.turn = PIECE_DARK

    def get_valid_moves(self):
        valid_moves = {}
        for row in range(ROWS):
            for col in range(COLS):
                piece = self.board.get_piece(row, col)
                if piece != 0 and piece.color == self.turn:
                    moves = self.board.get_valid_moves(piece)
                    if moves:
                        valid_moves[(row, col)] = moves
        return valid_moves